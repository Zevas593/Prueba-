package guardartxt;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class GuardarDatos {

    public boolean agregarPacienteAlArchivo(Persona p, String rutaArchivo) {
        try (BufferedWriter bw = new BufferedWriter(
                new FileWriter(rutaArchivo, true))) {
            String pacienteString = convertiPersonaToString(p);
            bw.write(pacienteString);
            bw.newLine();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private String convertiPersonaToString(Persona p) {
        StringBuilder sb = new StringBuilder();

        sb.append("Cédula: ").append(p.getNombre()).append(", ");
        sb.append("Nombre: ").append(p.getApellido()).append(", ");
        sb.append("Género: ").append(p.getEdad()).append(", ");
        sb.append("Género: ").append(p.getGenero());

        return sb.toString();
    }
}
