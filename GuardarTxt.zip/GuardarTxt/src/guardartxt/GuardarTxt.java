package guardartxt;

import java.util.Scanner;

public class GuardarTxt {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el nombre: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Ingrese el apellido: ");
        String apellido = scanner.nextLine();
        
        System.out.print("Ingrese la edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Ingrese el género: ");
        String genero = scanner.nextLine();

            
        Persona p = new Persona(nombre, apellido, edad, genero);
        GuardarDatos g = new GuardarDatos();
        boolean agregado = g.agregarPacienteAlArchivo(p, "personas.txt");
        
        if(agregado){
            System.out.println("Persona agregada con éxito");
        }else{
            System.out.println("Persona no se agregó");
        }
    }

}
